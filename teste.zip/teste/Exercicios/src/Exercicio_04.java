import java.util.Scanner;

//Codigo para calcular a diferença entre idades

public class Exercicio_04 {

    public static void main(String[] args) {

        var scanner = new Scanner(System.in);
        System.out.println("Informe o primeiro nome: ");
        var nome1 = scanner.next();
        System.out.println("Informe a Idade: ");
        var idade1 = scanner.nextInt();
        System.out.println("Informe o segundo nome: ");
        var nome2 = scanner.next();
        System.out.println("Informe a Idade: ");
        var idade2 = scanner.nextInt();
        var result = idade1 - idade2;
        System.out.println("O " + nome1 + " tem " + idade1 + " Anos");
        System.out.println("O " + nome2 + " tem " + idade2 + " Anos");
        System.out.printf("A diferença de idades vai ser %s Anos", result);

    }
}