import java.util.Scanner;

//Codigo para imprimir o nome e a idade de uma pessoa

public class Exercicio_01 {

    public static void main(String[] args) {

        var scanner = new Scanner(System.in);
        System.out.println("Informe o seu nome: ");
        var name = scanner.next();
        System.out.println("Informe o seu dia de nascimento: ");
        var dia = scanner.nextInt();
        System.out.println("Informe o seu mes de nascimento: ");
        var mes = scanner.nextInt();
        System.out.println("Informe o ano de nascimento: ");
        var ano = scanner.nextInt();
        System.out.printf("O seu nome é: %s\nA sua data de nascimento é:%s/%s/%s", name, dia, mes, ano);

    }


}