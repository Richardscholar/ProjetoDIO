import java.util.Scanner;

//Codigo para calcular a area de um quadrado

public class Exercicio_02 {

    public static void main(String[] args) {

        var scanner = new Scanner(System.in);
        System.out.println("Informe o valor de um lado: ");
        var lado1 = scanner.nextInt();
        System.out.println("Informe o valor do outro lado: ");
        var lado2 = scanner.nextInt();
        var result = lado1*lado2;
        System.out.println("A formula para calcular a area do quadrado e: lado x lado = result");
        System.out.printf("O calculo é: %s x %s = %s", lado1, lado2, result);
    }


}