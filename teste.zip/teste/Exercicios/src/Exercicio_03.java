import java.util.Scanner;

//Codigo para calcular a area de um retangulo

public class Exercicio_03 {

    public static void main(String[] args) {

        var scanner = new Scanner(System.in);
        System.out.println("Informe o valor da Base: ");
        var base = scanner.nextFloat();
        System.out.println("Informe o valor da Altura: ");
        var altura = scanner.nextFloat();
        var result = base * altura;
        System.out.println("A formula para calcular a area do retangulo é: Base * Altura = result");
        System.out.printf("O calculo da area do retangulo é: %s x %s = %s", base, altura, result);

    }
}