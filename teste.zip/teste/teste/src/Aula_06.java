import java.util.Scanner;

public class Aula_06 {

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        System.out.println("Informe o primeiro numero");
        var valor1 = scanner.nextInt(); //scanner.nextFloat();
        //System.out.println("Informe o primeiro numero");
        //var valor2 = scanner.nextInt();//scanner.nextFloat();
        //System.out.printf(valor1 + " + " + valor2 + " = " + (valor1 + valor2)); faz concatenações precisa colocaar o valor da operação entre parenteses
        //System.out.printf("%s + %s = %s", valor1, valor2, valor1 + valor2); operador de adição
        //System.out.printf("%s - %s = %s", valor1, valor2, valor1 - valor2); operador de subtração
        //System.out.printf("%s / %s = %s", valor1, valor2, valor1 / valor2); operador de divisao
        //System.out.printf("%s %% %s = %s", valor1, valor2, valor1 % valor2); verifica os restos da divisao
        //System.out.printf("%s * %s = %s", valor1, valor2, valor1 * valor2); operador de multiplicacao
        //System.out.printf("O resultado de %s é: %s ", valor1, Math.sqrt(valor1)); raiz quadrada
        System.out.printf("O resultado de %s é: %s ", valor1, Math.pow(valor1, 2)); //potencia


        /**
         * OBS:
         * var valor = 5;
         * valor += 12/;
         * valor = valor + 12
         *  e a mesma coisa com qualquer sinal
         *
         *  fazer tambem
         *  var valor = 50
         *  e a mesma coisa que fazer valor += 1 que vai dar 51
         *  System.out.println(++valor);
         *  System.out.println(valor++); usa ou imprima valor e na proxima linha atribui
         *  isso tambem vale para
         *  System.out.println(--valor);
         *  System.out.println(valor--); usa ou imprima valor e na proxima linha atribui
         *  System.out.println(valor)
         *
         *
         */

    }
}