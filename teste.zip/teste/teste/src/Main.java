import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        //operacoes em byte(/)(%)(^)(~)
    }
}

/**
 * 0 = False
 * 1 = True
 * 110 + 101
 * 1 com 1 e 1
 * 1 com 0 e 1
 * 0 com 1 e 1
 * porque ele uiliza o operador ou e so precisa de uma condicao verdadeira
 * (|) orbitwise
 * porque ele uiliza o operador ou e so precisa de uma condicao falsa
 * (&) andbitwse
 * se os numeros sao iguais retorna 0 se os numeros sao diferentes ele retorna 1 por causa das comparações e somado
 * (^) shorbitwise
 * ele faz a negação dos valores se por acaso e 1(True) vira 0(False) se for 0(False) vira 1(True)
 * (~) Complementebitwise
 *
 * shift operators
 * (<<) left deslocamento a esquerda x << y empurra para esquerda e completa com 0
 * x o numero e y quantidade de deslocamento
 * (>>) right deslocamento a direita x >> y
 * x quantidade de deslocamento e y numero ele completa com 1 quando negativo e completa com 0 quando e positovo a esquerda
 * (>>>) ansined shift operator que igual (<<)
 *
 *
 *
 */