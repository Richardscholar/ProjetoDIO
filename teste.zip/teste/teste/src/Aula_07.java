import java.util.Scanner;

public class Aula_07 {

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        var valor1 = 6;
        var binario1 = Integer.toBinaryString(valor1);
        System.out.printf("primeiro numero: %s\ne a representação binaria e %s\n", valor1, binario1);
        var valor2 = 7;
        var binario2 = Integer.toBinaryString(valor2);
        System.out.printf("Segundo numero: %s\ne a representacao binaria e %s\n", valor2, binario2);
        //var result = valor1 | valor2;
        //var result = valor1 & valor2;
        //var result = valor1 ^ valor2;
        //var result = ~valor1;
        var result = valor1 << valor2;
        var resultbinario = Integer.toBinaryString(result);
        System.out.printf("%s << %s = %s (representacao binaria %s)\n", valor1, valor2, result, resultbinario); //vai fazer as operacoes em cada byte dentro da variavel
        //System.out.printf("~%s = %s (representacao binaria %s)\n", valor1, result, resultbinario);
        System.out.println(Integer.toBinaryString(Integer.MAX_VALUE));//imprime o valor maximo
        //operacoes em byte(/)(%)(^)(~)
    }
}

/**
 * 0 = False
 * 1 = True
 * 110 + 101
 * 1 com 1 e 1
 * 1 com 0 e 1
 * 0 com 1 e 1
 * porque ele uiliza o operador ou e so precisa de uma condicao verdadeira
 * (|) orbitwise
 * porque ele uiliza o operador ou e so precisa de uma condicao falsa
 * (&) andbitwse
 * se os numeros sao iguais retorna 0 se os numeros sao diferentes ele retorna 1 por causa das comparações e somado
 * (^) shorbitwise
 * ele faz a negação dos valores se por acado e 1(True) vira 0(False) se for 0(False) vira 1(True)
 * (~) Complementebitwise
 *
 * shift operators
 * (<<) left deslocamento a esquerda x << y empurra para esquerda e completa com 0
 * x o numero e y quantidade de deslocamento
 * (>>) right deslocamento a direita x >> y
 * x quantidade de deslocamento e y numero ele completa com 1 quando negativo e completa com 0 quando e positovo a esquerda
 * (>>>) ansined shift operator que igual (<<)
 *
 *
 *
 */