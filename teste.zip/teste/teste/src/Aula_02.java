import java.util.Scanner;

public class Aula_02 {

    private final static String message = "hello World";

    public static void main(String[] args) {
        var scanner = new Scanner(System.in); //permite a leitura de dados de entrada do usuario
        System.out.println(message);
        System.out.println("Informe o seu nome");
        var name = scanner.next();
        System.out.println("Informe a sua idade: ");
        var age = scanner.nextInt();
        System.out.printf("O seu nome é %s e a sua idade é %s \n", name, age);
    }
}