import java.util.Scanner;

public class Aula_04 {

    public static void main(String[] args) {
        var scanner = new Scanner(System.in);
        System.out.println("digite um valor: ");
        var result = scanner.nextInt();
        System.out.println("voce e maior de idade: ");
        var age = scanner.nextBoolean();
        var comp = (result >= 18) || (age && result >= 16); //pode usar o ! aqui também !(result > 17);
        System.out.printf("O resultado será: %s", comp);

        //Operador de Comparação(==)
        //Operador de diferente(!=)
        //Operador maior ou maior igual(>)(>=)
        //Operador menor ou menor igual(<)(<=)

        //Operador de negação(!) inverte o valor da variavel
        /** !true = false
         *  !false = true
         */
        //Operador de uma condição OU(||) uma condição precisa ser verdadiera
        /** true  || true  = true
         *  true  || false = true
         *  false || true  = true
         *  false || false = false
         */
        //Operador de duas condições E(&&) as duas condiões precisam ser verdadeiras
        /** true  && true   = true
         *  true  && false  = false
         *  false && false  = false
         *  false && false  = false
         */

    }
}