import java.util.Scanner;

public class Aula_03{

    public static void main(String[] args) {

        /**
         //tipos de variaveis inteiras
         byte number1 = 1;
         short number2 = 1;
         int number3 = 1;
         long number4 = 1L;

         //tipos de variaveis flutuantes
         float number5 = 1.0f;
         double number6 = 1.0;

         //tipo de variavel caracter
         char caracter1 = 'a';
         String caracter2 = "a";

         //tipo de variavel booleano
         boolean bool1 = true;
         boolean bool2 = false;
         */
    }
}