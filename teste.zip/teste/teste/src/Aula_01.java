import java.util.Scanner;

public class Aula_01 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //permite a leitura de dados de entrada do usuario
        System.out.println("Informe o seu nome");
        String name = scanner.next();
        System.out.println("Informe a sua idade: ");
        int age = scanner.nextInt();
        System.out.printf("O seu nome é %s e a sua idade é %s \n", name, age);
    }
}